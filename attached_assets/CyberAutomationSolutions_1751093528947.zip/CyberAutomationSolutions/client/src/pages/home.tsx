import Navigation from "@/components/navigation";
import HeroSection from "@/components/hero-section";
import ServicesSection from "@/components/services-section";
import BlogPreviewSection from "@/components/blog-preview-section";
import ContactSection from "@/components/contact-section";
import Footer from "@/components/footer";
import ParticlesBackground from "@/components/particles-background";

export default function Home() {
  return (
    <div className="min-h-screen text-white overflow-x-hidden relative">
      <ParticlesBackground />
      <Navigation />
      <HeroSection />
      <ServicesSection />
      <BlogPreviewSection />
      <ContactSection />
      <Footer />
    </div>
  );
}
