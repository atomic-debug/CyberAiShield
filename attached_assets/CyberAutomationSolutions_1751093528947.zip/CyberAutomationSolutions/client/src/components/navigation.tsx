import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";

export default function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isVisible, setIsVisible] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      
      // Update backdrop blur state
      setIsScrolled(currentScrollY > 50);
      
      // Hide/show navigation based on scroll direction
      if (currentScrollY < lastScrollY || currentScrollY < 100) {
        setIsVisible(true);
      } else if (currentScrollY > lastScrollY && currentScrollY > 100) {
        setIsVisible(false);
      }
      
      setLastScrollY(currentScrollY);
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, [lastScrollY]);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <nav
      className={cn(
        "fixed top-4 left-4 right-4 z-50 transition-all duration-300 ease-in-out rounded-full max-w-6xl mx-auto",
        isScrolled
          ? "bg-zinc-900/60 backdrop-blur-2xl backdrop-saturate-200 border border-white/[0.08] shadow-lg"
          : "bg-zinc-950/40 backdrop-blur-xl backdrop-saturate-150 border border-white/[0.04]",
        isVisible ? "transform translate-y-0 opacity-100" : "transform -translate-y-24 opacity-0"
      )}
    >
      <div className="px-6">
        <div className="flex items-center justify-between h-14">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-br from-cyan-300 to-cyan-400 rounded-lg flex items-center justify-center">
              <span className="text-black font-bold text-sm">RX</span>
            </div>
            <span className="text-xl font-bold text-white">RactorIX</span>
            <span className="text-sm text-cyan-300 ml-2">Atomic Solution</span>
          </div>
          <div className="hidden md:flex items-center space-x-6">
            <button
              onClick={() => scrollToSection("services")}
              className="text-gray-300 hover:text-cyan-300 transition-colors px-3 py-2 rounded-lg hover:bg-white/5"
            >
              Services
            </button>
            <button
              onClick={() => scrollToSection("contact")}
              className="text-gray-300 hover:text-cyan-300 transition-colors px-3 py-2 rounded-lg hover:bg-white/5"
            >
              Contact
            </button>
            <button
              onClick={() => scrollToSection("contact")}
              className="bg-gradient-to-r from-cyan-300 to-cyan-400 hover:from-cyan-400 hover:to-cyan-300 text-black px-4 py-2 rounded-lg transition-all font-medium"
            >
              Get Started
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}