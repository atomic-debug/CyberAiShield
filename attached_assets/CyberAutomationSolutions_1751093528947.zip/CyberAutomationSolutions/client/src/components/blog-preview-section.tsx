import { Section } from "@/components/ui/section";
import { Calendar, ArrowRight } from "lucide-react";

const blogPosts = [
  {
    title: "Zero Trust Architecture: The Future of Enterprise Security",
    excerpt: "Learn how zero trust frameworks are revolutionizing cybersecurity by eliminating implicit trust and continuously validating every transaction.",
    date: "Dec 15, 2024",
    readTime: "5 min read",
    category: "Security Strategy"
  },
  {
    title: "AI-Powered Threat Detection: Beyond Traditional Security",
    excerpt: "Discover how machine learning algorithms are identifying sophisticated threats that traditional security tools miss.",
    date: "Dec 10, 2024",
    readTime: "7 min read",
    category: "AI & Security"
  },
  {
    title: "Compliance Made Simple: Navigating Modern Regulations",
    excerpt: "A comprehensive guide to maintaining compliance across GDPR, SOC 2, and other critical security frameworks.",
    date: "Dec 5, 2024",
    readTime: "6 min read",
    category: "Compliance"
  }
];

export default function BlogPreviewSection() {
  return (
    <Section className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-white">
            Latest Security Insights
          </h2>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            Stay ahead of emerging threats with expert analysis and practical guidance from our cybersecurity professionals.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogPosts.map((post, index) => (
            <article key={index} className="glass-card-enhanced p-6 group cursor-pointer">
              <div className="mb-4">
                <span className="inline-block px-3 py-1 text-xs font-medium rounded-full" style={{ color: '#FF6B35', backgroundColor: 'rgba(255, 107, 53, 0.1)' }}>
                  {post.category}
                </span>
              </div>
              
              <h3 className="text-xl font-semibold text-white mb-3 transition-colors group-hover:text-orange-500">
                {post.title}
              </h3>
              
              <p className="text-gray-300 text-sm leading-relaxed mb-4">
                {post.excerpt}
              </p>
              
              <div className="flex items-center justify-between text-xs text-gray-400">
                <div className="flex items-center space-x-2">
                  <Calendar className="w-4 h-4" />
                  <span>{post.date}</span>
                </div>
                <span>{post.readTime}</span>
              </div>
              
              <div className="mt-4 flex items-center text-sm font-medium transition-colors" style={{ color: '#FF6B35' }}>
                <span>Read More</span>
                <ArrowRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
              </div>
            </article>
          ))}
        </div>

        <div className="text-center mt-12">
          <button className="inline-flex items-center px-6 py-3 rounded-lg font-medium transition-all hover:bg-orange-500 hover:text-white" style={{ border: '1px solid #FF6B35', color: '#FF6B35' }}>
            View All Articles
            <ArrowRight className="w-4 h-4 ml-2" />
          </button>
        </div>
      </div>
    </Section>
  );
}