import { useEffect } from 'react';

export default function ParticlesBackground() {
  useEffect(() => {
    // Create animated particles exactly like in the reference design
    function createParticles() {
      const particlesContainer = document.getElementById('particles');
      if (!particlesContainer) return;

      // Clear existing particles
      particlesContainer.innerHTML = '';
      
      const particleCount = 50;

      for (let i = 0; i < particleCount; i++) {
        const particle = document.createElement('div');
        particle.className = 'particle';
        particle.style.cssText = `
          position: absolute;
          width: 2px;
          height: 2px;
          background: rgba(100, 255, 218, 0.6);
          border-radius: 50%;
          animation: float 15s infinite linear;
          left: ${Math.random() * 100}%;
          animation-delay: ${Math.random() * 15}s;
          animation-duration: ${Math.random() * 10 + 10}s;
        `;
        particlesContainer.appendChild(particle);
      }
    }

    createParticles();

    // Recreate particles on window resize
    const handleResize = () => createParticles();
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <div 
      id="particles"
      className="fixed inset-0 pointer-events-none overflow-hidden"
      style={{ zIndex: -1 }}
    />
  );
}