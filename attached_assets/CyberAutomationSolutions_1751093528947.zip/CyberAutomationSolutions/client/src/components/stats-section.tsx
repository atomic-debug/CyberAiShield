import { Section } from "@/components/ui/section";

const stats = [
  {
    number: "300%",
    label: "Faster Threat Detection",
  },
  {
    number: "99.99%",
    label: "Attack Prevention Rate",
  },
  {
    number: "$50M+",
    label: "Losses Prevented",
  },
  {
    number: "Zero",
    label: "Successful Breaches",
  },
];

export default function StatsSection() {
  return (
    <Section className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="glass-card-enhanced rounded-2xl p-8 lg:p-12">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 text-center">
            {stats.map((stat, index) => (
              <div key={index} className="animate-float" style={{ animationDelay: `${index * 0.2}s` }}>
                <div className="text-4xl lg:text-5xl font-bold text-cyan-300 mb-2">
                  {stat.number}
                </div>
                <div className="text-gray-300 text-lg">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Section>
  );
}