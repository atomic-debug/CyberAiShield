import { Section } from "@/components/ui/section";

const services = [
  {
    icon: "⚡",
    title: "Real-Time Threat Detection",
    description: "Advanced AI-powered monitoring that identifies and responds to security threats with rapid precision and automated incident response."
  },
  {
    icon: "🔒",
    title: "Advanced Security Architecture",
    description: "Comprehensive protection systems designed to safeguard your critical business infrastructure with enterprise-grade security protocols."
  },
  {
    icon: "🚀",
    title: "Scalable ROI Solutions",
    description: "Advanced technology that maximizes security investment returns while optimizing operational efficiency and reducing overall costs."
  },
  {
    icon: "🎯",
    title: "Strategic Security Consulting",
    description: "Industry-leading solutions that provide competitive advantages through comprehensive security strategy and implementation guidance."
  },
  {
    icon: "⚡",
    title: "Zero-Trust Architecture",
    description: "Implementing comprehensive zero-trust security frameworks that verify every access request and secure all network communications."
  },
  {
    icon: "💎",
    title: "Enterprise Security Solutions",
    description: "Comprehensive security infrastructure designed for large-scale operations with 24/7 monitoring and dedicated support services."
  }
];

export default function ServicesSection() {
  return (
    <Section id="services" className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-white">
            Comprehensive Security Solutions
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div key={index} className="glass-card-enhanced p-8 text-center">
              <h3 className="text-xl font-semibold mb-4" style={{ color: '#FF6B35' }}>{service.title}</h3>
              <p className="text-gray-300 leading-relaxed">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </Section>
  );
}