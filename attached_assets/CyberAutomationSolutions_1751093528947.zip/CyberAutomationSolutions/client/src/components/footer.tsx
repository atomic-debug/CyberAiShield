export default function Footer() {
  return (
    <footer className="py-12 border-t border-bright-yellow/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center space-x-2 mb-4 md:mb-0">
            <div className="w-8 h-8 bg-gradient-to-br from-electric-yellow to-bright-yellow rounded-lg flex items-center justify-center">
              <span className="text-black font-bold text-sm">RX</span>
            </div>
            <span className="text-xl font-bold text-white">RactorIX</span>
            <span className="text-sm text-bright-yellow ml-2">Atomic Solution</span>
          </div>
          <div className="text-gray-400 text-sm text-center md:text-right">
            <p>&copy; 2024 RactorIX. All rights reserved.</p>
            <p className="mt-1">Revolutionizing IT through AI-driven automation</p>
          </div>
        </div>
      </div>
    </footer>
  );
}
