import { Section } from "@/components/ui/section";

export default function HeroSection() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <Section className="min-h-screen flex items-center relative pt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div className="text-center lg:text-left">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6">
              <span className="text-white">Stop Threats</span><br />
              <span className="text-orange-500" style={{ color: '#FF6B35' }}>
                Before They Start
              </span>
            </h1>
            <p className="text-lg md:text-xl text-gray-300 mb-8 max-w-2xl">
              AI-powered security that learns, adapts, and protects your business 24/7. 
              Transform vulnerabilities into <strong style={{ color: '#FF6B35' }}>competitive advantages</strong>.
            </p>
            <button
              onClick={() => scrollToSection("consultation")}
              className="inline-block px-8 py-4 text-white font-bold text-lg rounded-full transition-all duration-300 hover:-translate-y-1 hover:shadow-2xl"
              style={{ 
                background: 'linear-gradient(135deg, #FF6B35 0%, #F45432 100%)',
                boxShadow: '0 10px 30px rgba(255, 107, 53, 0.4)',
                animation: 'slideInLeft 1s ease-out 0.4s both'
              }}
            >
              Get Advanced Protection
            </button>
          </div>
          
          <div className="flex justify-center lg:justify-end">
            <div className="relative w-80 h-80">
              <div 
                className="w-full h-full rounded-full flex items-center justify-center"
                style={{ 
                  background: 'radial-gradient(circle, rgba(255, 107, 53, 0.1), rgba(244, 84, 50, 0.05))',
                  border: '2px solid #FF6B35',
                  borderRadius: '50% 50% 50% 50% / 60% 60% 40% 40%',
                  animation: 'pulse 2s infinite'
                }}
              >
                <div className="w-32 h-32" style={{ color: '#FF6B35', filter: 'drop-shadow(0 0 20px #FF6B35)' }}>
                  <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M30 40 C30 20, 50 10, 100 10 C150 10, 170 20, 170 40 L170 120 C170 150, 140 170, 100 170 C60 170, 30 150, 30 120 Z"/>
                    <path d="M50 90 L150 70" strokeWidth="6"/>
                    <path d="M50 110 L140 90" strokeWidth="4"/>
                    <path d="M130 100 C140 104, 150 110, 156 120" strokeWidth="4"/>
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Section>
  );
}