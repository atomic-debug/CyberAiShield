import { Section } from "@/components/ui/section";
import { Lock } from "lucide-react";

export default function CTASection() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <Section id="consultation" className="py-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="glass-card-enhanced rounded-2xl p-8 lg:p-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Ready to Secure Your <em className="text-cyan-300">Future</em>?
          </h2>
          <p className="text-lg md:text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Transform your cybersecurity approach from reactive to proactive. Experience comprehensive protection that enhances your business operations.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <button
              onClick={() => scrollToSection("contact")}
              className="inline-block px-8 py-4 bg-gradient-to-r from-cyan-300 to-cyan-400 text-gray-900 font-bold text-lg rounded-full transition-all duration-300 hover:-translate-y-1"
              style={{ boxShadow: '0 10px 30px rgba(100, 255, 218, 0.3)' }}
            >
              Schedule Consultation
            </button>
          </div>
        </div>
      </div>
    </Section>
  );
}
