# RactorIX - AI-Driven IT Consulting Landing Page

## Overview

This is a modern, professional landing page for RactorIX, a Cyber Consulting / IT MSP AI Automation Agency. The application is built with a full-stack architecture featuring a React frontend with shadcn/ui components and an Express.js backend with PostgreSQL database integration.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **UI Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom dark theme and night sky aesthetics
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM for type-safe database operations
- **Session Management**: PostgreSQL session store with connect-pg-simple
- **API Design**: RESTful API endpoints with proper error handling

### Data Storage
- **Primary Database**: PostgreSQL (configured for Neon serverless)
- **ORM**: Drizzle ORM with schema-first approach
- **Migration System**: Drizzle Kit for database migrations
- **Fallback Storage**: In-memory storage for development/testing

## Key Components

### Frontend Components
1. **Hero Section**: Animated landing area with starry background
2. **Services Section**: Service cards with benefits and features
3. **CTA Section**: Call-to-action with consultation booking
4. **Contact Section**: Contact form with validation
5. **Navigation**: Responsive navigation with smooth scrolling
6. **Footer**: Company information and branding

### Backend Components
1. **Contact API**: Handles contact form submissions
2. **Storage Layer**: Abstracted storage interface with PostgreSQL and in-memory implementations
3. **Validation**: Zod schema validation for API requests
4. **Error Handling**: Centralized error handling middleware

### UI System
- **Component Library**: Comprehensive shadcn/ui component set
- **Design System**: Consistent spacing, typography, and color schemes
- **Responsive Design**: Mobile-first approach with breakpoint considerations
- **Accessibility**: ARIA-compliant components with keyboard navigation

## Data Flow

1. **Contact Form Submission**:
   - User fills out contact form (name, email, message)
   - Frontend validates input and sends POST request to `/api/contact`
   - Backend validates with Zod schema and stores in database
   - Success/error feedback displayed via toast notifications

2. **Page Navigation**:
   - Smooth scrolling navigation between sections
   - Client-side routing for different pages (currently only home and 404)

3. **Static Content**:
   - All content is statically rendered with responsive design
   - Images and assets served from attached_assets directory

## External Dependencies

### Frontend Dependencies
- **UI Framework**: React, Radix UI components
- **Styling**: Tailwind CSS, class-variance-authority
- **State Management**: TanStack Query
- **Form Handling**: React Hook Form with Hookform resolvers
- **Icons**: Lucide React
- **Date Handling**: date-fns

### Backend Dependencies
- **Database**: @neondatabase/serverless, Drizzle ORM
- **Validation**: Zod, zod-validation-error
- **Session Management**: connect-pg-simple
- **Development**: tsx for TypeScript execution

### Build Tools
- **Frontend**: Vite with React plugin
- **Backend**: esbuild for production builds
- **Development**: Replit-specific plugins for cartographer and error overlay

## Deployment Strategy

### Development
- **Frontend**: Vite dev server with hot module replacement
- **Backend**: tsx with nodemon-like behavior for TypeScript execution
- **Database**: Environment variable `DATABASE_URL` for connection

### Production
- **Build Process**: 
  - Frontend: Vite build to `dist/public`
  - Backend: esbuild bundle to `dist/index.js`
- **Static Serving**: Express serves built frontend assets
- **Database**: PostgreSQL via connection string
- **Environment**: Production mode with optimized assets

### Configuration
- **Environment Variables**: `DATABASE_URL`, `NODE_ENV`
- **Database Config**: Drizzle config points to PostgreSQL dialect
- **Build Targets**: ES modules with node platform targeting

## Changelog

```
Changelog:
- June 28, 2025. Initial setup
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```